from django.urls import path
from . import views

urlpatterns = [
    path('', views.leave_list, name='leave_list'),
    path('add/', views.add_leave, name='add_leave'),
    path('edit/<int:id>/', views.edit_leave, name='edit_leave'),
    path('delete/<int:id>/', views.delete_leave, name='delete_leave'),


    #api
    #  path('api/leaves/', views.getLeaveList, name='get_leave'),
    # path('api/leaves/add/', views.addLeave, name='add_leave_api'),
    # path('api/leaves/update/<int:pk>/', views.updateLeave, name='update_leave_api'),
    # path('api/leaves/delete/<int:pk>/', views.deleteLeave, name='delete_leave_api'),

]
