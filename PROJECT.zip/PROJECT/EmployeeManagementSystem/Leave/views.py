# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from .models import Leave
#api

from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Leave
from .serializers import LeaveSerializer

# def leave_list(request):
#     leaves = Leave.objects.all()
#     return render(request, 'leave_list.html', {'leaves': leaves})

# def add_leave(request):
#     if request.method == "POST":
#         Leave.objects.create(
#             employee_name=request.POST['employee_name'],
#             leave_type=request.POST['leave_type'],
#             start_date=request.POST['start_date'],
#             end_date=request.POST['end_date'],
#             reason=request.POST['reason']
#         )
#         return redirect('leave_list')
#     return render(request, 'add_leave.html')

# def edit_leave(request, id):
#     leave = get_object_or_404(Leave, pk=id)
#     if request.method == "POST":
#         leave.employee_name = request.POST['employee_name']
#         leave.leave_type = request.POST['leave_type']
#         leave.start_date = request.POST['start_date']
#         leave.end_date = request.POST['end_date']
#         leave.reason = request.POST['reason']
#         leave.save()
#         return redirect('leave_list')
#     return render(request, 'edit_leave.html', {'leave': leave})

# def delete_leave(request, id):
#     leave = get_object_or_404(Leave, pk=id)
#     leave.delete()
#     return redirect('leave_list')


# #api
# @api_view(['GET'])
# def getLeaveList(request):
#     leaves = Leave.objects.all()
#     serializer = LeaveSerializer(leaves, many=True)
#     return Response(serializer.data)

# @api_view(['POST'])
# def addLeave(request):
#     serializer = LeaveSerializer(data=request.data)
#     if serializer.is_valid():
#         serializer.save()
#         return Response(serializer.data, status=status.HTTP_201_CREATED)
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['PUT'])
# def updateLeave(request, pk):
#     try:
#         leave = Leave.objects.get(pk=pk)
#     except Leave.DoesNotExist:
#         return Response({"message": "Leave not found"}, status=status.HTTP_404_NOT_FOUND)

#     serializer = LeaveSerializer(leave, data=request.data)
#     if serializer.is_valid():
#         serializer.save()
#         return Response(serializer.data)
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['DELETE'])
# def deleteLeave(request, pk):
#     try:
#         leave = Leave.objects.get(pk=pk)
#     except Leave.DoesNotExist:
#         return Response({"message": "Leave not found"}, status=status.HTTP_404_NOT_FOUND)

#     leave.delete()
#     return Response({"message": "Leave deleted successfully"}, status=status.HTTP_200_OK)






# 🔹 Leave List (GET)
@api_view(['GET'])
def leave_list(request):
    leaves = Leave.objects.all()
    return render(request, 'leave_list.html', {'leaves': leaves})


# 🔹 Add Leave (GET/POST)
@api_view(['GET', 'POST'])
def add_leave(request):
    if request.method == "POST":
        serializer = LeaveSerializer(data=request.POST)
        if serializer.is_valid():
            serializer.save()
            return redirect('leave_list')
    return render(request, 'add_leave.html')

# 🔹 EDIT Leave (GET / POST)
@api_view(['GET', 'POST'])
def edit_leave(request, id):
    try:
        leave = Leave.objects.get(pk=id)

        if request.method == 'POST':
            serializer = LeaveSerializer(leave, data=request.POST)
            if serializer.is_valid():
                serializer.save()
                return redirect('leave_list')
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return render(request, 'edit_leave.html', {'leave': leave})

    except Leave.DoesNotExist:
        return Response({'error': 'Leave not found'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# 🔹 DELETE Leave (POST)
@api_view(['POST'])
def delete_leave(request, id):
    try:
        leave = Leave.objects.get(pk=id)
        leave.delete()
        return redirect('leave_list')

    except Leave.DoesNotExist:
        return Response({'error': 'Leave not found'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


# # 🔹 Edit Leave (GET/POST)
# @api_view(['GET', 'POST'])
# def edit_leave(request, id):
#     leave = get_object_or_404(Leave, pk=id)
#     if request.method == "POST":
#         serializer = LeaveSerializer(leave, data=request.POST)
#         if serializer.is_valid():
#             serializer.save()
#             return redirect('leave_list')
#     return render(request, 'edit_leave.html', {'leave': leave})


# # 🔹 Delete Leave (POST)
# @api_view(['POST'])
# def delete_leave(request, id):
#     leave = get_object_or_404(Leave, pk=id)
#     leave.delete()
#     return redirect('leave_list')