from django.urls import path
from . import views

urlpatterns = [
    path('', views.attendance_list, name='attendance_list'),
    path('add/', views.add_attendance, name='add_attendance'),
    path('edit/<int:id>/', views.edit_attendance, name='edit_attendance'),
    path('delete/<int:id>/', views.delete_attendance, name='delete_attendance'),



    path('attendance/<int:id>/replace/', views.replace_attendance_with_leave, name='replace_attendance_with_leave'),

    #api
    #  path('api/attendance/', views.getAttendanceList, name='get_attendance'),
    # path('api/attendance/add/', views.addAttendance, name='add_attendance_api'),
    # path('api/attendance/update/<int:pk>/', views.updateAttendance, name='update_attendance_api'),
    # path('api/attendance/delete/<int:pk>/', views.deleteAttendance, name='delete_attendance_api'),
]
