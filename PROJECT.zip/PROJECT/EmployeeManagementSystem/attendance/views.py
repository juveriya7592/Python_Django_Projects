

# Create your views he
from django.shortcuts import render, redirect, get_object_or_404
from .models import Attendance 
from Leave.models import Leave
#api
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Attendance
from .serializers import AttendanceSerializer



# def attendance_list(request):
#     records = Attendance.objects.all()
#     return render(request, 'attendance_list.html', {'records': records})

# def add_attendance(request):
#     if request.method == 'POST':
#         employee = request.POST['employee_name']
#         date = request.POST['date']
#         status = request.POST['status']
#         Attendance.objects.create(employee_name=employee, date=date, status=status)
#         return redirect('attendance_list')
#     return render(request, 'add_attendance.html')

# def edit_attendance(request, id):
#     record = get_object_or_404(Attendance, id=id)
#     if request.method == 'POST':
#         record.employee_name = request.POST['employee_name']
#         record.date = request.POST['date']
#         record.status = request.POST['status']
#         record.save()
#         return redirect('attendance_list')
#     return render(request, 'edit_attendance.html', {'record': record})

# def delete_attendance(request, id):
#     record = get_object_or_404(Attendance, id=id)
#     record.delete()
#     return redirect('attendance_list')








# def replace_attendance_with_leave(request, id):
#     record = get_object_or_404(Attendance, id=id)
    
    
#     record.delete()
    
#     Leave.objects.create(
#         employee_name=record.employee_name,
#         leave_type='Emergency',
#         start_date=record.date,
#         end_date=record.date,
#         reason='Leave created bases on attendance corrections',
#     )  
#     return redirect('attendance_list')  






# #api

# @api_view(['GET'])
# def getAttendanceList(request):
#     attendances = Attendance.objects.all()
#     serializer = AttendanceSerializer(attendances, many=True)
#     return Response(serializer.data)

# @api_view(['POST'])
# def addAttendance(request):
#     serializer = AttendanceSerializer(data=request.data)
#     if serializer.is_valid():
#         serializer.save()
#         return Response(serializer.data, status=status.HTTP_201_CREATED)
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['PUT'])
# def updateAttendance(request, pk):
#     try:
#         attendance = Attendance.objects.get(pk=pk)
#     except Attendance.DoesNotExist:
#         return Response({"message": "Attendance not found"}, status=status.HTTP_404_NOT_FOUND)

#     serializer = AttendanceSerializer(attendance, data=request.data)
#     if serializer.is_valid():
#         serializer.save()
#         return Response(serializer.data)
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['DELETE'])
# def deleteAttendance(request, pk):
#     try:
#         attendance = Attendance.objects.get(pk=pk)
#     except Attendance.DoesNotExist:
#         return Response({"message": "Attendance not found"}, status=status.HTTP_404_NOT_FOUND)

#     attendance.delete()
#     return Response({"message": "Attendance deleted successfully"}, status=status.HTTP_200_OK)






# 🔹 LIST attendance
@api_view(['GET'])
def attendance_list(request):
    records = Attendance.objects.all()
    return render(request, 'attendance_list.html', {'records': records})

# 🔹 ADD attendance (GET/POST)
@api_view(['GET', 'POST'])
def add_attendance(request):
    if request.method == 'POST':
        serializer = AttendanceSerializer(data=request.POST)
        if serializer.is_valid():
            serializer.save()
            return redirect('attendance_list')
    return render(request, 'add_attendance.html')

# # 🔹 EDIT attendance (GET/POST)
# @api_view(['GET', 'POST'])
# def edit_attendance(request, id):
#     record = get_object_or_404(Attendance, pk=id)
#     if request.method == 'POST':
#         serializer = AttendanceSerializer(record, data=request.POST)
#         if serializer.is_valid():
#             serializer.save()
#             return redirect('attendance_list')
#     return render(request, 'edit_attendance.html', {'record': record})

# # 🔹 DELETE attendance (POST)
# @api_view(['POST'])
# def delete_attendance(request, id):
#     record = get_object_or_404(Attendance, pk=id)
#     record.delete()
#     return redirect('attendance_list')

# 🔹 EDIT attendance (GET/POST) with error handling
@api_view(['GET', 'POST'])
def edit_attendance(request, id):
    try:
        record = Attendance.objects.get(pk=id)

        if request.method == 'POST':
            serializer = AttendanceSerializer(record, data=request.POST)
            if serializer.is_valid():
                serializer.save()
                return redirect('attendance_list')
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return render(request, 'edit_attendance.html', {'record': record})

    except Attendance.DoesNotExist:
        return Response({'error': 'Attendance record not found'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    

# 🔹 DELETE attendance (POST) with try-except
@api_view(['POST'])
def delete_attendance(request, id):
    try:
        record = Attendance.objects.get(pk=id)
        record.delete()
        return redirect('attendance_list')
    except Attendance.DoesNotExist:
        return Response({'error': 'Attendance record not found'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    

# 🔹 REPLACE attendance with leave (POST)
@api_view(['POST'])
def replace_attendance_with_leave(request, id):
    record = get_object_or_404(Attendance, id=id)
    
    # Delete attendance
    record.delete()

    # Create emergency leave
    Leave.objects.create(
        employee_name=record.employee_name,
        leave_type='Emergency',
        start_date=record.date,
        end_date=record.date,
        reason='Leave created based on attendance correction'
    )

    return redirect('attendance_list')