from django.urls import path
from . import views

urlpatterns = [
    path('', views.department_list, name='department_list'),
    path('add/', views.add_department, name='add_department'),
    path('edit/<int:id>/', views.edit_department, name='edit_department'),
    path('delete/<int:id>/', views.delete_department, name='delete_department'),




    #rest api
    # [path('api/departments/', views.getDepartments, name='get_departments'),
    # path('api/departments/add/', views.addDepartment, name='add_department_api'),
    # path('api/departments/update/<int:pk>/', views.updateDepartment, name='update_department_api'),
    # path('api/departments/delete/<int:pk>/', views.deleteDepartment, name='d]elete_department_api'),


]
