# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from .models import Department

from rest_framework.decorators import api_view    #rest api
from rest_framework.response import Response
from rest_framework import status
from .models import Department
from .serializers import DepartmentSerializer

# def department_list(request):
#     departments = Department.objects.all()
#     return render(request, 'department_list.html', {'departments': departments})

# def add_department(request):
#     if request.method == 'POST':
#         name = request.POST['name']
#         head = request.POST['head']
#         location = request.POST['location']
#         Department.objects.create(name=name, head=head, location=location)
#         return redirect('department_list')
#     return render(request, 'add_department.html')

# def edit_department(request, id):
#     department = get_object_or_404(Department, id=id)
#     if request.method == 'POST':
#         department.name = request.POST['name']
#         department.head = request.POST['head']
#         department.location = request.POST['location']
#         department.save()
#         return redirect('department_list')
#     return render(request, 'edit_department.html', {'department': department})

# def delete_department(request, id):
#     department = get_object_or_404(Department, id=id)
#     department.delete()
#     return redirect('department_list')






#rest api
# @api_view(['GET'])
# def getDepartments(request):
#     departments = Department.objects.all()
#     serializer = DepartmentSerializer(departments, many=True)
#     return Response(serializer.data)

# @api_view(['POST'])
# def addDepartment(request):
#     serializer = DepartmentSerializer(data=request.data)
#     if serializer.is_valid():
#         serializer.save()
#         return Response(serializer.data, status=status.HTTP_201_CREATED)
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['PUT'])
# def updateDepartment(request, pk):
#     try:
#         department = Department.objects.get(pk=pk)
#     except Department.DoesNotExist:
#         return Response({"message": "Department not found"}, status=status.HTTP_404_NOT_FOUND)

#     serializer = DepartmentSerializer(department, data=request.data)
#     if serializer.is_valid():
#         serializer.save()
#         return Response(serializer.data)
#     return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

# @api_view(['DELETE'])
# def deleteDepartment(request, pk):
#     try:
#         department = Department.objects.get(pk=pk)
#     except Department.DoesNotExist:
#         return Response({"message": "Department not found"}, status=status.HTTP_404_NOT_FOUND)

#     department.delete()
#     return Response({"message": "Department deleted successfully"}, status=status.HTTP_200_OK)





#  List departments
@api_view(['GET'])
def department_list(request):
    departments = Department.objects.all()
    return render(request, 'department_list.html', {'departments': departments})

#  Add department (GET/POST)
@api_view(['GET', 'POST'])
def add_department(request):
    if request.method == 'POST':
        serializer = DepartmentSerializer(data=request.POST)
        if serializer.is_valid():
            serializer.save()
            return redirect('department_list')
    return render(request, 'add_department.html')

# # 🔹 Edit department (GET/POST)
# @api_view(['GET', 'POST'])
# def edit_department(request, id):
#     department = get_object_or_404(Department, pk=id)
#     if request.method == 'POST':
#         serializer = DepartmentSerializer(department, data=request.POST)
#         if serializer.is_valid():
#             serializer.save()
#             return redirect('department_list')
#     return render(request, 'edit_department.html', {'department': department})

# # 🔹 Delete department (POST)
# @api_view(['DELETE'])
# def delete_department(request, id):
#     department = get_object_or_404(Department, pk=id)
#     department.delete()
#     return redirect('department_list')


@api_view(['GET', 'POST'])
def edit_department(request, id):
    try:
        department = Department.objects.get(pk=id)
    except Department.DoesNotExist:
        return Response({'error': 'Department not found'}, status=status.HTTP_404_NOT_FOUND)

    if request.method == 'POST':
        serializer = DepartmentSerializer(department, data=request.POST)
        if serializer.is_valid():
            serializer.save()
            return redirect('department_list')
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    return render(request, 'edit_department.html', {'department': department})


@api_view(['POST'])
def delete_department(request, id):
    try:
        department = Department.objects.get(pk=id)
        department.delete()
        return redirect('department_list')
    except Department.DoesNotExist:
        return Response({'error': 'Department not found'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)