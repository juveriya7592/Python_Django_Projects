from django.urls import path
from . import views

urlpatterns = [
    path('', views.employee_home, name='employee_home'),
    path('list/', views.employee_list, name='employee_list'),
    path('add/', views.add_employee, name='add_employee'),
    path('edit/<int:pk>/', views.edit_employee, name='edit_employee'),
    path('delete/<int:pk>/', views.delete_employee, name='delete_employee'),







    #rest api
    # path('api/employees/', views.getEmployees, name='get_employees'),
    # path('api/employees/add/', views.addEmployee, name='add_employee_api'),
    # path('api/employees/update/<int:pk>/', views.updateEmployee, name='update_employee_api'),
    # path('api/employees/delete/<int:pk>/', views.deleteEmployee, name='delete_employee_api'),
]
