# Create your views here.
from django.shortcuts import render, redirect, get_object_or_404
from .models import Employee
#rest api
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from .models import Employee
from .serializers import EmployeeSerializer

# def employee_home(request):
#     return render(request, 'home.html')

# def employee_list(request):
#     employees = Employee.objects.all()
#     return render(request, 'list.html', {'employees': employees})

# def add_employee(request):
#     if request.method == 'POST':
#         name = request.POST['name']
#         email = request.POST['email']
#         phone = request.POST['phone']
#         department = request.POST['department']
#         joining_date = request.POST['joining_date']
#         Employee.objects.create(name=name, email=email, phone=phone, department=department, joining_date=joining_date)
#         return redirect('employee_list')
#     return render(request, 'addEmployee.html')

# def edit_employee(request, pk):
#     employee = get_object_or_404(Employee, pk=pk)
#     if request.method == 'POST':
#         employee.name = request.POST['name']
#         employee.email = request.POST['email']
#         employee.phone = request.POST['phone']
#         employee.department = request.POST['department']
#         employee.joining_date = request.POST['joining_date']
#         employee.save()
#         return redirect('employee_list')
#     return render(request, 'editEmployee.html', {'employee': employee})

# def delete_employee(request, pk):
#     employee = get_object_or_404(Employee, pk=pk)
#     employee.delete()
#     return redirect('employee_list')






#  GET all employees
@api_view(['GET'])
def employee_list(request):
    employees = Employee.objects.all()
    return render(request, 'list.html', {'employees': employees})


#add employee
@api_view(['GET', 'POST'])
def add_employee(request):
    if request.method == 'POST':
        serializer = EmployeeSerializer(data=request.POST)
        if serializer.is_valid():
            serializer.save()
            return redirect('employee_list')
    return render(request, 'addEmployee.html')


#  UPDATE employee (GET for form, POST/PUT for submit)
# @api_view(['GET', 'POST'])
# def edit_employee(request, pk):
#     employee = get_object_or_404(Employee, pk=pk)
#     if request.method == 'POST':
#         serializer = EmployeeSerializer(employee, data=request.POST)
#         if serializer.is_valid():
#             serializer.save()
#             return redirect('employee_list')
#     return render(request, 'editEmployee.html', {'employee': employee})


# # DELETE employee
# @api_view(['POST'])
# def delete_employee(request, pk):
#     employee = get_object_or_404(Employee, pk=pk)
#     employee.delete()
#     return redirect('employee_list')

#  EDIT Employee (GET / POST) - DRY + try
@api_view(['GET', 'POST'])
def edit_employee(request, pk):
    try:
        employee = Employee.objects.get(pk=pk)

        if request.method == 'POST':
            serializer = EmployeeSerializer(employee, data=request.POST)
            if serializer.is_valid():
                serializer.save()
                return redirect('employee_list')
            else:
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        return render(request, 'editEmployee.html', {'employee': employee})

    except Employee.DoesNotExist:
        return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)


#  DELETE Employee (POST) - DRY + try
@api_view(['POST'])
def delete_employee(request, pk):
    try:
        employee = Employee.objects.get(pk=pk)
        employee.delete()
        return redirect('employee_list')

    except Employee.DoesNotExist:
        return Response({'error': 'Employee not found'}, status=status.HTTP_404_NOT_FOUND)
    except Exception as e:
        return Response({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)



def employee_home(request):
    return render(request, 'home.html')